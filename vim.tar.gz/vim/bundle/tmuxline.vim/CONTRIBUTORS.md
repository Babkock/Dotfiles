# Contributors

 * [Darren Cheng](https://github.com/darrenli) - jellybeans theme
 * [Nick Ostrovsky](https://github.com/firedev) - minimal theme
