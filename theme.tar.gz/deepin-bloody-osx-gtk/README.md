# Deepin-bloody-osx-gtk

The default GTK theme for deepin with modified colors and window buttons.

For GNOME

# Preview

![preview](https://github.com/marinos-m/deepin-bloody-osx-gtk/blob/master/preview.png)

![preview 2](https://github.com/marinos-m/deepin-bloody-osx-gtk/blob/master/preview2.png)

# Alternative version with different switches

![alternative preview](https://github.com/marinos-m/deepin-bloody-osx-gtk/blob/master/alter-preview.png)
